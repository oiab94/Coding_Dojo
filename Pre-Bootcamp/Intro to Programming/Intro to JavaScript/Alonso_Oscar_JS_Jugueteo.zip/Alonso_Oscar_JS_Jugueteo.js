/**
 * La aplicación debe medir la altura de un niño, puede mostrar si el niño es 
 * suficientemente alto para subirse a la montaña rusa. Mostrara el mensaje 
 * correcto al niño.
 */
// Paso 1
var alturaNiño = 145;

// Paso 2
function muestraSiElNiñoPuedeSubirALaMontañaRusa() {
// Paso 3
	if (alturaNiño > 52) console.log("Subete niño!");
	else console.log("Lo siento chico. Tal vez el proximo año");
}

// Ejecución función
muestraSiElNiñoPuedeSubirALaMontañaRusa();